import pyttsx3

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')

engine.setProperty('voice', voices[0].id)

def speak(audio): 
    '''THIS FUNCTION WILL SPEAK YOUR device. In case you have to change the voice male or female, ctrl + click \n on speak function .  .'''
    engine.say(audio)
    engine.runAndWait()